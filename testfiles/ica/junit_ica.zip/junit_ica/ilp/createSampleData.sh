#!/bin/sh

# Licensed Materials - Property of IBM
#
# 5725-D69
#
# (C) Copyright IBM Corp. 2016 All rights reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.

rm -f /tmp/districts.out
rm -f /tmp/areas.out
rm -f /tmp/zones3.out

db2 connect to iocdata
drop table ioc.districts
drop table ioc.areas
drop table ioc.zones
db2 connect reset

db2se import_shape IOCDATA -filename  /tmp/junit_ica/shapefiles/district2 -srsName WGS84_SRS_1003 -tableSchema IOC  -tableName districts -spatialColumn LOCATION -typeName ST_MULTIPOLYGON -messagesFile /tmp/districts.out
db2se import_shape IOCDATA -filename  /tmp/junit_ica/shapefiles/reportingAreas2 -srsName WGS84_SRS_1003 -tableSchema IOC -tableName areas -spatialColumn LOCATION -typeName ST_MULTIPOLYGON -messagesFile /tmp/areas.out 
db2se import_shape IOCDATA -filename  /tmp/junit_ica/shapefiles/ZONE3 -srsName WGS84_SRS_1003 -tableSchema IOC -tableName zones -spatialColumn LOCATION -typeName ST_MULTIPOLYGON -messagesFile /tmp/zones3.out

db2 connect to iocdata
db2 -tvf /tmp/junit_ica/ilp/ilp.ddl
db2 -tvf /tmp/junit_ica/ilp/ilpJuv.ddl
db2 -tvf /tmp/junit_ica/ilp/arrests.ddl
db2 -tvf /tmp/junit_ica/ilp/arrestsJuv.ddl
db2 -tvf /tmp/junit_ica/ilp/ilp.sql
db2 -tvf /tmp/junit_ica/ilp/ilpJuv.sql
db2 -tvf /tmp/junit_ica/ilp/arrests.sql
db2 -tvf /tmp/junit_ica/ilp/arrestsJuv.sql